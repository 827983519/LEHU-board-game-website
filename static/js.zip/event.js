$(function () {
    // switch (window.location.hash) {
        // case "#joined":
        //     $("#join").show();
        //     break;
        // case "#not-joined":
        //     $("#quit").show();
        //     break;
        //default:
            $("#join").show();
            $("#quit").show();
            $("#edit").show();
            $("#cancel-event").show();
    // }

    function toggle() {
        $("#edit").toggle();
        $("#cancel-event").toggle();
        $("#save").toggle();
        $("#cancel").toggle();

        $(".field>.value").toggle();
        $(".field>.input").toggle();
    }
    $("#edit").click(toggle);

    $("#cancel").click(toggle);

    $("#save").click(function () {
        toggle()
    })
})